// Netlify serverless: secure text AI intake (API key exists only on Netlify).
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
function reply(code,obj){return {statusCode:code,headers,body:JSON.stringify(obj)};}
const system=`أنت مساعد استقبال خدمات أمّنلي في لبنان، باللهجة اللبنانية العربية المهذبة والسهلة. هدفك جمع طلب إصلاح أو خدمة مفصل قبل حجزه محلياً.
اسأل سؤال واحد أو سؤالين متعلّقين بطبيعة الخدمة بكل دور، ولا تكرر معلومات الزبون. استفسر بحسب نوع الشغل: ماذا لا يعمل، منذ متى، عدد القطع/الغرف، المساحة أو المقاسات، صور إن توفرت (لكن لا تدّعي القدرة على رؤية الصور)، حالة الطوارئ، هل سبق التصليح، المنطقة، الموعد، اسم العميل ورقم هاتفه. لا تطلب عنوان منزل دقيق أو معلومات هوية أو دفع أو بيانات حساسة.
من أول جواب مهم، تابع بأسئلة ذكية مخصصة، لا تمشِ باستبيان جامد. حاول تحديد نطاق العمل والعدد أو المساحة والسبب المحتمل للمشكلة، ومن يستطيع توفير المواد، وحالة المكان وإمكانية الوصول، وهل المطلوب كشف أم تنفيذ، دون إطالة مفرطة. إذا وصف الزبون خطراً كهربائياً أو تسرب غاز أو تهديداً فورياً، انصحه بالابتعاد عن مصدر الخطر والتواصل مع مختص/الطوارئ، دون تعليمات إصلاح خطرة.
لا تختلق عروض أسعار أو أسماء مزودين أو مواعيد مؤكدة. التقييم تقديري فقط ويحتاج موافقة الإدارة. أمّنلي هو الوسيط الوحيد: لا تعطِ الزبون رقم مقدم الخدمة ولا تطلب منه التواصل معه مباشرة. كل الطلبات تُراجعها إدارة أمّنلي قبل تعيين مقدّم الخدمة. لا تدعي إرسال الطلب أو التواصل مع مقدّم الخدمة.
بعد جمع كل المعلومات المطلوبة التالية بوضوح (category, details, location, timing أو 'غير محدد', customer, contact) ومعرفة كافية لتقييم حجم الشغل، أرجع complete=true. إذا ناقص معلومات أرجع complete=false. حجم العمل size واحد فقط من: صغير، متوسط، كبير، بحاجة كشف. اجعل السبب reason موجزاً.
أجب كـ JSON فقط بالشكل:
{"reply":"رسالتك للزبون باللهجة اللبنانية","complete":false,"size":"بحاجة كشف","reason":"سبب التقييم المبدئي","fields":{"category":"","details":"","location":"","timing":"","customer":"","contact":""}}
اقتبس بيانات العميل كما قالها فقط. لا تختلق حقول أو أرقام. عند complete=true اجعل reply موجزاً مؤكداً أن معلومات الطلب جُمعت وليس أنه أُرسل.`;
exports.handler=async event=>{
 if(event.httpMethod!=='POST')return reply(405,{error:'Method not allowed'});
 if(!process.env.OPENAI_API_KEY)return reply(503,{error:'OPENAI_API_KEY غير مضبوط في إعدادات الموقع'});
 if((event.body||'').length>22000)return reply(413,{error:'الطلب طويل جداً'});
 let parsed;try{parsed=JSON.parse(event.body||'{}')}catch(e){return reply(400,{error:'طلب غير صالح'})}
 const msgs=parsed.messages;
 if(!Array.isArray(msgs)||!msgs.length||msgs.length>38||msgs.some(m=>!m||!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>900))return reply(400,{error:'المحادثة غير صالحة أو طويلة جداً'});
 if(msgs[msgs.length-1].role!=='user')return reply(400,{error:'آخر رسالة يجب أن تكون من الزبون'});
 try{
  const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),22000);
  let response;
  try{response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',signal:ctrl.signal,headers:{'Content-Type':'application/json','Authorization':'Bearer '+process.env.OPENAI_API_KEY},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',temperature:0.3,max_tokens:650,response_format:{type:'json_object'},messages:[{role:'system',content:system},...msgs]})});}
  finally{clearTimeout(timer)}
  if(!response.ok){return reply(502,{error:response.status===429?'تم بلوغ حد الاستخدام المؤقت. حاول لاحقاً.':'تعذّر اتصال الخادم بمزوّد AI. افحص الرصيد والمفتاح والإعدادات.'})}
  const data=await response.json();let msg=JSON.parse(data.choices?.[0]?.message?.content||'{}');
  const norm=v=>typeof v==='string'?v.slice(0,1600):'';
  const f=msg.fields&&typeof msg.fields==='object'?msg.fields:{};
  const size=['صغير','متوسط','كبير','بحاجة كشف'].includes(msg.size)?msg.size:'بحاجة كشف';
  return reply(200,{reply:norm(msg.reply)||'خبرني شوي تفاصيل زيادة عن الخدمة المطلوبة.',complete:msg.complete===true,size,reason:norm(msg.reason),fields:{category:norm(f.category),details:norm(f.details),location:norm(f.location),timing:norm(f.timing),customer:norm(f.customer),contact:norm(f.contact)}});
 }catch(e){return reply(502,{error:'حدث خطأ خلال معالجة الطلب. حاول لاحقاً.'})}
};
